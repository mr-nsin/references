docker container rm -f traefik
docker container rm -f catalog
docker container rm -f monolith
