docker container rm -f postgres api
docker network rm test-net
docker volume rm pg-data
