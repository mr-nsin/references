#!/bin/bash
touch /app/healthy
sleep 30
rm -rf /app/healthy
sleep 600