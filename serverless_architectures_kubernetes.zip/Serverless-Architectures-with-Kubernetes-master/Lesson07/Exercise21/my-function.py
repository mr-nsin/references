def main(event, context):
    return "Welcome to Serverless Architectures with Kubernetes"