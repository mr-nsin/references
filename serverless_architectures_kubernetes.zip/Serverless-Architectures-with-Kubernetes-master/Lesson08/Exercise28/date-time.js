function main() {
    var currentDateTime = new Date();
    return { currentDateTime: currentDateTime };
}
