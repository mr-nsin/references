## Enable the ingress controller on minikube

```
minikube addons enable ingress
```