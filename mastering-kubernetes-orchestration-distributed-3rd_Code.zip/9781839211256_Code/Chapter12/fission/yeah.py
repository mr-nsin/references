def main():
    return 'Yeah, it works!!!'