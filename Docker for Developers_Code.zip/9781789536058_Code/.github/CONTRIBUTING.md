# Contributing to Project

### Code of Conduct

Modus has adopted a [Code of Conduct](./CODE_OF_CONDUCT.md) that we expect project participants to adhere to.

### Submitting a Pull Request

If you are a first time contributor, you can learn how from this _free_ series [How to Contribute to an Open Source Project on GitHub](https://egghead.io/series/how-to-contribute-to-an-open-source-project-on-github).

### License

By contributing, you agree that your contributions will be licensed under it's [license](../LICENSE).
