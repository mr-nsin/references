# Docker for Developers - Code in Action Steps
## Conclusion – End of the Road, but not the Journey

 Note: This recording is of a MacBook Pro with iTerm2.

This video goes with Chapter 16 of the Packt Publishing book "Docker for Developers"
You should be reading along with Chapter 16 and loading Metasploit
Feel free to pause the video to be able to take your time viewing the commands and output.

### Load metasploit container
- [ ] Pull the container
- [ ] Review output
- [ ] Run the container 
- [ ] The framework console will load
- [ ] Once loaded commands can be executed. 
