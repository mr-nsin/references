#!/bin/bash

docker pull metasploitframework/metasploit-framework
sudo docker run --rm -it metasploitframework/metasploit-framework


