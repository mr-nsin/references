#!/usr/bin/env bash
set -euo pipefail
docker exec -it chapter6_redis_1 redis-cli
