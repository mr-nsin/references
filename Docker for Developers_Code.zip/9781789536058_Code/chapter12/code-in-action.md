# Docker for Developers - Code in Action Steps

## Chapter 12 Introduction to Container Security
Note: This recording is of a MacBook Pro with iTerm2.

This video goes with Chapter 12 of the Packt Publishing book "Docker for Developers"
You should be reading along with Chapter 12 and preparing to edit the Dockerfile
Feel free to pause the video to be able to take your time viewing the commands and output.

- [ ] Open the Dockerfile
- [ ] Add in the command to use alpine
- [ ] Add in the commands to create a user and group
- [ ] Add in the USER command
- [ ] Run the docker build command with the tag
- [ ] Review the output

