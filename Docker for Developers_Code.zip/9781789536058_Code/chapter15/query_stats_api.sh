curl -sk <options> https://<ip>:<port>/<rest endpoint>  --cert <path/to/cert.pem> --key <path/to/key.pem -cacert <path/to/ca.pem>
