# Docker for Developers - Code in Action Steps

## Chapter 14 Advanced Docker Security – Secrets, Secret Commands, Tagging, and Labels
Note: This recording is of a MacBook Pro with iTerm2.

This video goes with Chapter 14 of the Packt Publishing book "Docker for Developers"
You should be reading along with Chapter 14 and preparing to edit the Dockerfile
Feel free to pause the video to be able to take your time viewing the commands and output.

### Add and Remove secret
- [ ] Initalize swarm
- [ ] Create a secret using the id_rsa key
- [ ] List the secrets to see the new one
- [ ] Inspect the secret to see the JSON output 
- [ ] Run the docker rm command do remove the id_rsa key secret

### Edit the Dockerfile
- [ ] Open the Dockerfile up in your favorite text editor 
- [ ] Update the EXAMPLE credentials
- [ ] Run the build command 
- [ ] Review the output

### Add a label
- [ ] Create a new secret with the label

