# Chapter 11 - Scale Docker applications with Envoy, prove it works with k6.io

# Credits
The [shipitclicker/templates/configmap-envoy.yaml](shipitclicker/templates/configmap-envoy.yaml) configuration file has been adapted from [Envoy example code, especially the front proxy and redis examples](https://github.com/envoyproxy/envoy/tree/master/examples) which are [Apache 2-licenced](https://github.com/envoyproxy/envoy/blob/master/LICENSE), and bear the following copyright notice:

   © Copyright 2016-2020, Envoy Project Authors 

