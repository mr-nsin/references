# Schedule

```
+------------+-----------------------------------------------------------+------------+------------+
| CHAPTER    | TITLE                                                     | DRAFT      | FINAL      |
+------------+-----------------------------------------------------------+------------+------------+
|  Chapter 1 | Introduction                                              | 11/12/2019 | 01/18/2020 |
|  Chapter 2 | Using Docker containers and VirtualBox for development    | 12/03/2019 | 01/22/2020 |
|  Chapter 3 | Building and pushing docker image to the dockerhub site   | 12/24/2019 | 01/26/2020 |
|  Chapter 4 | Composing systems using containers                        | 01/14/2020 | 01/30/2020 |
+------------+-----------------------------------------------------------+------------+------------+
```
