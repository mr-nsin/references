#!/bin/sh

# start-subscriber.sh

yarn start


