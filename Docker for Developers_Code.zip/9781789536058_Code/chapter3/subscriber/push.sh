#!/bin/sh

docker push dockerfordevelopers/subscriber

