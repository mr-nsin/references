#!/bin/sh

# start-publisher.sh

yarn start


