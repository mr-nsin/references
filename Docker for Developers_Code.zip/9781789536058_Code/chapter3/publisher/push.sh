#!/bin/sh

docker push dockerfordevelopers/publisher

