#!/bin/sh

./start-mosca.sh
./start-mongodb.sh
./start-redis.sh
